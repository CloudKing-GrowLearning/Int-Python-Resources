import json, urllib.request
import pandas as pd
import matplotlib.pyplot as plt


with urllib.request.urlopen("https://data.seattle.gov/resource/fire-911.json") as url:
    json_data = json.load(url)

    data = pd.DataFrame.from_dict(json_data)

    print(data.head())