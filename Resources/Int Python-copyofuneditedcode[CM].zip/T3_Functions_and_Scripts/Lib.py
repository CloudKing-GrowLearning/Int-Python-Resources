x = 5
y = 4

def compare (x, y):
    if x > y:
        print('The first number is larger')
    elif x == y:
        print('Both numbers are the same')
    else:
        print('The second number is larger')