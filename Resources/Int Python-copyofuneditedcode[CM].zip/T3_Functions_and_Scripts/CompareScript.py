import Lib


Lib.compare(5, 6)