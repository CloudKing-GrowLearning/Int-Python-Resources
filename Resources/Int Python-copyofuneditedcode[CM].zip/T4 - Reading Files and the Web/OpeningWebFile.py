import csv
from itertools import islice
import codecs

#with open('C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/data-asset-recovery.csv', 'rb') as f:
    #first_rows = list(islice(csv.reader(codecs.open(f)), None, 136))

#if '\0' in open('C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/data-asset-recovery.csv', 'r').read():
    #print("you have null bytes in your input file")
#else:
    #print("you don't")

#reader = csv.reader(x.replace('\0', '') for x in 'C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/data-asset-recovery.csv')

with open('C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/data-asset-recovery.csv') as fd:
    reader=csv.reader(fd)
    interestingrows=[row for idx, row in enumerate(reader) if idx in (136,155)]

print(interestingrows)