from urllib.request import urlopen
import csv


url = 'https://www.gov.uk/government/uploads/system/uploads/attachment_data/file/119382/data-asset-recovery.csv'

response = urlopen(url)
data = response.read()

file_name = 'C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/downloaded_data.csv'
f = open(file_name, 'wb')
f.write(data)
f.close()

with open(file_name, 'r', encoding='utf-8', errors='ignore') as infile, open(file_name + 'final.csv', 'w') as outfile:
    inputs = csv.reader(infile)
    output = csv.writer(outfile)
    for index, row in enumerate(inputs):
        output.writerow(row)