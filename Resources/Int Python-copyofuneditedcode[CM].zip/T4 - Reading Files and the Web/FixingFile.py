import csv

lines = []
#with open('output.txt','r') as f:
    #for line in f.readlines():
        #lines.append(line[:-1])

with open('C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/edited-data-asset-recovery.csv','w') as correct:
    writer = csv.writer(correct, dialect = 'excel')
    with open('C:/Users/User/Desktop/Int Python/T4 - Reading Files and the Web/data-asset-recovery.csv', 'r', encoding='ISO-8859-1') as mycsv:
        reader = csv.reader( (line.replace('\0','') for line in mycsv) )
        for row in reader:
            if row[0] not in lines:
                writer.writerow(row)